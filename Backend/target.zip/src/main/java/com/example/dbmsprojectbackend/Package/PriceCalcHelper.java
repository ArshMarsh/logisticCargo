package com.example.dbmsprojectbackend.Package;

public class PriceCalcHelper {
	private Double weight;
	private Double volume;

	public Double getWeight() {
		return weight;
	}

	public void setWeight(Double weight) {
		this.weight = weight;
	}

	public Double getVolume() {
		return volume;
	}

	public void setVolume(Double volume) {
		this.volume = volume;
	}



}
